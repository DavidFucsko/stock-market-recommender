import { Component, Inject, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-page',
  templateUrl: './stocks-page.component.html',
  styleUrls: ['./stocks-page.component.scss']
})
export class StocksPageComponent {

  constructor() { }

}
