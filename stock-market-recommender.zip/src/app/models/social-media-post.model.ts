export class SocialMediaPost {
    title: string;
    post: string;
}