export class SocialPlatforms {
    facebook: boolean;
    twitter: boolean;
    instagram: boolean;
}
