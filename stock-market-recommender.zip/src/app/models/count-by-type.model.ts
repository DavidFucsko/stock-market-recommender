export class CountByType {
    mediaType: string;
    count: number;

    constructor() {
        this.mediaType = '';
        this.count = 0;
    }
}
